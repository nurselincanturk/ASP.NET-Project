﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.Sql;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace yazilimproje
{
    public partial class anasayfa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            

            //if (Session["email1"] == null)
            //    Response.Redirect("giriskayit.aspx");
            //else
            //    Response.Write("Hoşgeldiniz " + Session["email1"].ToString());





            //SqlConnection vtbag = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");
            //vtbag.Open();

            ///*Urun bilgi baglantıları*/


            //SqlCommand sorgu = new SqlCommand("SELECT * FROM haber", vtbag);
            //SqlDataReader oku = sorgu.ExecuteReader();
            //rptUrun.DataSource = oku;
            //rptUrun.DataBind();

            //sorgu.Dispose();
            //rptUrun.Dispose();
            //oku.Dispose();
            //oku.Close();

            ///*bitiss */







            //vtbag.Dispose();
            //vtbag.Close();
            //string baglantiCumlesi = "Data Source=LAPTOP-VB4BVHDI\\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True";
            //SqlConnection baglanti = new SqlConnection(baglantiCumlesi);
            //string sorgu = "Select haberBaslik from haber  where haberResim='canererkin.jpeg'";
            //string deger;
            //SqlCommand komut = new SqlCommand(sorgu, baglanti);
            //baglanti.Open();
            //deger = (string)komut.ExecuteScalar();
            //baglanti.Close();
            //label1.Text = deger;


            //string sorgu1 = "Select haberBaslik from haber  where haberResim='aykut.jpg'";
            //string deger1;
            //SqlCommand komut1 = new SqlCommand(sorgu1, baglanti);
            //baglanti.Open();
            //deger1 = (string)komut1.ExecuteScalar();
            //baglanti.Close();
            //label12.Text = deger1;

            //string sorgu2 = "Select haberBaslik from haber  where haberResim='geri9.png'";
            //string deger2;
            //SqlCommand komut2 = new SqlCommand(sorgu2, baglanti);
            //baglanti.Open();
            //deger2 = (string)komut2.ExecuteScalar();
            //baglanti.Close();
            //label13.Text = deger2;

            //string sorgu4 = "Select haberBaslik from haber  where haberResim='muslera.jpg'";
            //string deger4;
            //SqlCommand komut4 = new SqlCommand(sorgu4, baglanti);
            //baglanti.Open();
            //deger4 = (string)komut4.ExecuteScalar();
            //baglanti.Close();
            //label15.Text = deger4;
        }
    }
}