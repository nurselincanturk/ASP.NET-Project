﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace yazilimproje
{
    public partial class aa : System.Web.UI.Page
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");
        //SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=WebProje;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            lblSuccessMessage.Visible = false;
            lblerrorrmessages.Visible = false;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
            SqlCommand sqlCmd = new SqlCommand("uyeEkle", sqlCon);
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.AddWithValue("@name", adtxt.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@lastname", soyadtxt.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@email", emailtxt.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@password", TextBox21.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@kullaniciadi", kullanicitxt.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@takim", takimtxt.Text.Trim());
            sqlCmd.ExecuteNonQuery();
            sqlCon.Close();


            lblSuccessMessage.Visible = true;
            //Response.Redirect("Anasayfa.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string email1 = emailgiristxt.Text;
            string password = sifretxt.Text;
            SqlConnection baglan = new SqlConnection("Data Source=LAPTOP-VB4BVHDI\\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");
            SqlCommand sorgula = new SqlCommand("SELECT * FROM uye WHERE email=@email AND password=@password", baglan);
            sorgula.Parameters.AddWithValue("@email", email1);
            sorgula.Parameters.AddWithValue("@password", password);
            baglan.Open();
            SqlDataReader oku = sorgula.ExecuteReader();
            if (oku.Read())
            {
                Session["email1"] = oku["email"].ToString();
                Response.Redirect("anasayfa.aspx");
            }
            else
                lblerrorrmessages.Text = "Kullanıcı adı yada şifre hatalı!";
            oku.Close();
            baglan.Close();
            baglan.Dispose();


        }
    }
}