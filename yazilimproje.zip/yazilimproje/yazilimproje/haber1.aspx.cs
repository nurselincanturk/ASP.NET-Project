﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace yazilimproje.haberlerson
{
    public partial class haber1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Button1.Visible = false;
            string baglantiCumlesi = "Data Source=LAPTOP-VB4BVHDI\\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True";
            SqlConnection baglanti = new SqlConnection(baglantiCumlesi);
            string sorgu = "Select haberBaslik from haber  where haberResim='erkin.jpeg'";
            string deger;
            SqlCommand komut = new SqlCommand(sorgu, baglanti);
            baglanti.Open();
            deger = (string)komut.ExecuteScalar();
            baglanti.Close();
            label1.Text = deger;
            
            
            string sorgu2 = "Select haberYazi from haber where haberResim='erkin.jpeg'";
            string deger2;
            SqlCommand komut2 = new SqlCommand(sorgu2, baglanti);
            baglanti.Open();
            deger2 = (string)komut2.ExecuteScalar();
            baglanti.Close();
            label2.Text = deger2;

            SqlConnection vtbag = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");
            vtbag.Open();

            /*Urun bilgi baglantıları*/


            SqlCommand sorgu3 = new SqlCommand("SELECT * FROM tartisma1", vtbag);
            SqlDataReader oku = sorgu3.ExecuteReader();
            rptUrun.DataSource = oku;
            rptUrun.DataBind();

            sorgu3.Dispose();
            rptUrun.Dispose();
            oku.Dispose();
            oku.Close();

            /*bitiss */




        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");
          
            if (Session["email1"] != null)
            {

                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();
                }
                SqlCommand sqlCmd = new SqlCommand("tartismaBirYorum", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
               sqlCmd.Parameters.AddWithValue("@email", Session["email1"]);
              //  sqlCmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@yorum", txtYorum.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();

                lblSuccessMessage.Text = "Saved succesfully";
                Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);

            }
            else
            {
                lblErrorMessage.Text = "Yalnızca Üyelerimiz Yorum Yapabilir.. " ;


                Button1.Visible = true;

            }



           
        }

        protected void Unnamed_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void asdbutton_Click(object sender, ImageClickEventArgs e)
        {//bu kısım

            //SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");

            //if (sqlCon.State == ConnectionState.Closed)
            //{
            //    sqlCon.Open();
            //}
            //SqlCommand sqlCmd = new SqlCommand("tartismaBirYorum", sqlCon);
            //sqlCmd.CommandType = CommandType.StoredProcedure;
            //sqlCmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
            //sqlCmd.Parameters.AddWithValue("@yorum", txtYorum.Text.Trim());
            //sqlCmd.ExecuteNonQuery();
            //sqlCon.Close();

            //lblSuccessMessage.Text = "Saved succesfully";

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}