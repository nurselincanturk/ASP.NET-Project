﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace yazilimproje
{
    public partial class abdulkerim : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection vtbag = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");
            vtbag.Open();

            /*Urun bilgi baglantıları*/


            SqlCommand sorgu = new SqlCommand("SELECT * FROM abdulkerim", vtbag);
            SqlDataReader oku = sorgu.ExecuteReader();
            rptUrun.DataSource = oku;
            rptUrun.DataBind();

            sorgu.Dispose();
            rptUrun.Dispose();
            oku.Dispose();
            oku.Close();

            /*bitiss */







            vtbag.Dispose();
            vtbag.Close();
        }
    }
}