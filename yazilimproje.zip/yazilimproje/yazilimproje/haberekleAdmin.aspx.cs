﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace yazilimproje
{
    public partial class admin : System.Web.UI.Page
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
            SqlCommand sqlCmd = new SqlCommand("haberEkle", sqlCon);
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.AddWithValue("@haberBaslik", txtHbrBaslik.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@haberYazi", txtHaber.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@haberResim", txtResim.Text.Trim());
            sqlCmd.ExecuteNonQuery();
            sqlCon.Close();
           
                lblSuccessMessage.Text = "Saved succesfully";
            
           
        }
    }
}