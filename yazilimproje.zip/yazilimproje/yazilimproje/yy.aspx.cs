﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Drawing;

namespace yazilimproje
{
    public partial class yy : System.Web.UI.Page
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=WebProje;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["email1"] == null)
            //    Response.Redirect("YENİ.aspx");
            //else
            //    Response.Write("Hoşgeldiniz " + Session["email1"].ToString());



        }

        protected void btnSave_Click(object sender, EventArgs e)
        {



        }
       
      

        protected void button1_Click(object sender, EventArgs e)
        {

        }

       
    }
}