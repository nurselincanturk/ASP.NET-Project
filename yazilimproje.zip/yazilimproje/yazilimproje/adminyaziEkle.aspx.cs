﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
namespace yazilimproje
{
    public partial class yaziEkle : System.Web.UI.Page
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");
        SqlConnection baglan = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            GridView2.Visible = false;
            GridView3.Visible = false;
            GridView4.Visible = false; GridView6.Visible = false;
            GridView5.Visible = false;

            SqlCommand komut = new SqlCommand();

            SqlDataAdapter da = new SqlDataAdapter(komut);

            DataSet ds = new DataSet();



            komut.CommandText = "Select * from ridvan";



            komut.Connection = baglan;

            baglan.Open();



            komut.ExecuteNonQuery();



            da.Fill(ds);



            baglan.Close();



            GridView1.DataSource = ds;



            GridView1.DataBind();


        }
        protected void Gridview1_SelectedIndexChanged(object sender, EventArgs e)

        {

            //gridview secili satirdaki degerleri textbox aktariyoruz.

            TextBox4.Text = GridView1.SelectedRow.Cells[1].Text;

            
            //secili satir rengini degistiriyoruz.

            foreach (GridViewRow row in GridView1.Rows)

            {

                if (row.RowIndex == GridView1.SelectedIndex)

                {

                    row.BackColor = ColorTranslator.FromHtml("Red");



                }

                else

                {

                    row.BackColor = ColorTranslator.FromHtml("White");



                }

            }

        }
        protected void Gridview2_SelectedIndexChanged(object sender, EventArgs e)

        {

            //gridview secili satirdaki degerleri textbox aktariyoruz.

            TextBox4.Text = GridView2.SelectedRow.Cells[1].Text;


            //secili satir rengini degistiriyoruz.

            foreach (GridViewRow row in GridView2.Rows)

            {

                if (row.RowIndex == GridView2.SelectedIndex)

                {

                    row.BackColor = ColorTranslator.FromHtml("Red");



                }

                else

                {

                    row.BackColor = ColorTranslator.FromHtml("White");



                }

            }

        }
        protected void Gridview3_SelectedIndexChanged(object sender, EventArgs e)

        {

            //gridview secili satirdaki degerleri textbox aktariyoruz.

            TextBox4.Text = GridView3.SelectedRow.Cells[1].Text;


            //secili satir rengini degistiriyoruz.

            foreach (GridViewRow row in GridView3.Rows)

            {

                if (row.RowIndex == GridView3.SelectedIndex)

                {

                    row.BackColor = ColorTranslator.FromHtml("Red");



                }

                else

                {

                    row.BackColor = ColorTranslator.FromHtml("White");



                }

            }

        }
        protected void Gridview4_SelectedIndexChanged(object sender, EventArgs e)

        {

            //gridview secili satirdaki degerleri textbox aktariyoruz.

            TextBox4.Text = GridView4.SelectedRow.Cells[1].Text;


            //secili satir rengini degistiriyoruz.

            foreach (GridViewRow row in GridView4.Rows)

            {

                if (row.RowIndex == GridView4.SelectedIndex)

                {

                    row.BackColor = ColorTranslator.FromHtml("Red");



                }

                else

                {

                    row.BackColor = ColorTranslator.FromHtml("White");



                }

            }

        }
        protected void Gridview5_SelectedIndexChanged(object sender, EventArgs e)

        {

            //gridview secili satirdaki degerleri textbox aktariyoruz.

            TextBox4.Text = GridView5.SelectedRow.Cells[1].Text;


            //secili satir rengini degistiriyoruz.

            foreach (GridViewRow row in GridView5.Rows)

            {

                if (row.RowIndex == GridView5.SelectedIndex)

                {

                    row.BackColor = ColorTranslator.FromHtml("Red");



                }

                else

                {

                    row.BackColor = ColorTranslator.FromHtml("White");



                }

            }

        }
        protected void Gridview6_SelectedIndexChanged(object sender, EventArgs e)

        {

            //gridview secili satirdaki degerleri textbox aktariyoruz.

            TextBox4.Text = GridView6.SelectedRow.Cells[1].Text;


            //secili satir rengini degistiriyoruz.

            foreach (GridViewRow row in GridView6.Rows)

            {

                if (row.RowIndex == GridView6.SelectedIndex)

                {

                    row.BackColor = ColorTranslator.FromHtml("Red");



                }

                else

                {

                    row.BackColor = ColorTranslator.FromHtml("White");



                }

            }

        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            {
                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();
                }


                if (DropDownList1.SelectedIndex == 1)
                {
                    SqlCommand sqlCmd = new SqlCommand("ridvanYaziEkle", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@yaziBaslik", txtbaslik.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@yazi", txtyazi.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();

                    txtbaslik.Text = "";

                    txtyazi.Text = "";
                    lblSuccessMessage.Text = "Saved succesfully";
                }
                else if (DropDownList1.SelectedIndex == 2)
                {
                    SqlCommand sqlCmd = new SqlCommand("abdulYaziEkle", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@yaziBaslik", txtbaslik.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@yazi", txtyazi.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    txtbaslik.Text = "";

                    txtyazi.Text = "";
                    lblSuccessMessage.Text = "Saved succesfully";

                }
                else if (DropDownList1.SelectedIndex == 3)
                {
                    SqlCommand sqlCmd = new SqlCommand("sinanYaziEkle", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@yaziBaslik", txtbaslik.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@yazi", txtyazi.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    txtbaslik.Text = "";

                    txtyazi.Text = "";
                    lblSuccessMessage.Text = "Saved succesfully";

                }
                else if (DropDownList1.SelectedIndex == 4)
                {
                    SqlCommand sqlCmd = new SqlCommand("ahmetYaziEkle", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@yaziBaslik", txtbaslik.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@yazi", txtyazi.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    txtbaslik.Text = "";

                    txtyazi.Text = "";
                    lblSuccessMessage.Text = "Saved succesfully";

                }
                else if (DropDownList1.SelectedIndex == 5)
                {
                    SqlCommand sqlCmd = new SqlCommand("gokmenYaziEkle", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@yaziBaslik", txtbaslik.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@yazi", txtyazi.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    txtbaslik.Text = "";

                    txtyazi.Text = "";
                    lblSuccessMessage.Text = "Saved succesfully";

                }
                else if (DropDownList1.SelectedIndex == 6)
                {
                    SqlCommand sqlCmd = new SqlCommand("tumerYaziEkle", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@yaziBaslik", txtbaslik.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@yazi", txtyazi.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    txtbaslik.Text = "";

                    txtyazi.Text = "";
                    lblSuccessMessage.Text = "Saved succesfully";

                }

            }
        }

        protected void sil_Click(object sender, EventArgs e)
        {
            string numarasi = TextBox4.Text;
            SqlConnection baglanti = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");

            //  SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["baglantiCumlemiz"].ConnectionString);
          


            if (DropDownList2.SelectedIndex == 1)
            {
                SqlCommand silKomutu = new SqlCommand("DELETE FROM ridvan WHERE yaziBaslik=@yaziBaslik", baglanti);
                silKomutu.Parameters.AddWithValue("@yaziBaslik", numarasi);
                baglanti.Open();
                silKomutu.ExecuteNonQuery();
                baglanti.Close();
                Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);




            }
            else if (DropDownList2.SelectedIndex == 2)
            {
                SqlCommand silKomutu = new SqlCommand("DELETE FROM abdulkerim WHERE yaziBaslik=@yaziBaslik", baglanti);
                silKomutu.Parameters.AddWithValue("@yaziBaslik", numarasi);
                baglanti.Open();
                silKomutu.ExecuteNonQuery();
                baglanti.Close();
                Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);



            }
            else if (DropDownList2.SelectedIndex == 3)
            {
                SqlCommand silKomutu = new SqlCommand("DELETE FROM sinan WHERE yaziBaslik=@yaziBaslik", baglanti);
                silKomutu.Parameters.AddWithValue("@yaziBaslik", numarasi);
                baglanti.Open();
                silKomutu.ExecuteNonQuery();
                baglanti.Close();
                Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);



            }
            else if (DropDownList2.SelectedIndex == 4)
            {
                SqlCommand silKomutu = new SqlCommand("DELETE FROM AhmetCakar WHERE yaziBaslik=@yaziBaslik", baglanti);
                silKomutu.Parameters.AddWithValue("@yaziBaslik", numarasi);
                baglanti.Open();
                silKomutu.ExecuteNonQuery();
                baglanti.Close();
                Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);



            }
            else if (DropDownList2.SelectedIndex == 5)
            {
                SqlCommand silKomutu = new SqlCommand("DELETE FROM gokmen WHERE yaziBaslik=@yaziBaslik", baglanti);
                silKomutu.Parameters.AddWithValue("@yaziBaslik", numarasi);
                baglanti.Open();
                silKomutu.ExecuteNonQuery();
                baglanti.Close();
                Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);



            }
            else if (DropDownList2.SelectedIndex == 6)
            {
                SqlCommand silKomutu = new SqlCommand("DELETE FROM tumer WHERE yaziBaslik=@yaziBaslik", baglanti);
                silKomutu.Parameters.AddWithValue("@yaziBaslik", numarasi);
                baglanti.Open();
                silKomutu.ExecuteNonQuery();
                baglanti.Close();
                Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);



            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList2.SelectedIndex == 1)
            {
                GridView1.Visible = true;
                GridView2.Visible = false;
                GridView3.Visible = false;
                GridView4.Visible = false; GridView6.Visible = false;
                GridView5.Visible = false;
            }
            else if (DropDownList2.SelectedIndex == 2)
            {
                GridView1.Visible = false;
               
                GridView3.Visible = false;
                GridView4.Visible = false; GridView6.Visible = false;
                GridView5.Visible = false;
                GridView2.Visible = true;

            }
            else if (DropDownList2.SelectedIndex ==3)
            {
                GridView1.Visible = false;

                GridView2.Visible = false;
                GridView4.Visible = false; GridView6.Visible = false;
                GridView5.Visible = false;
                GridView3.Visible = true;

            }
            else if (DropDownList2.SelectedIndex ==4)
            {
                GridView1.Visible = false;

                GridView3.Visible = false;
                GridView2.Visible = false; GridView6.Visible = false;
                GridView5.Visible = false;
                GridView4.Visible = true;

            }
            else if (DropDownList2.SelectedIndex == 5)
            {
                GridView1.Visible = false;

                GridView3.Visible = false;
                GridView4.Visible = false; GridView6.Visible = false;
                GridView2.Visible = false;
                GridView5.Visible = true;

            }
            else if (DropDownList2.SelectedIndex == 6)
            {
                GridView1.Visible = false;

                GridView3.Visible = false;
                GridView4.Visible = false; GridView6.Visible = true;
                GridView5.Visible = false;
                GridView2.Visible = false;

            }

        }
    }
}