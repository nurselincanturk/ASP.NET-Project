﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace yazilimproje
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (Session["email1"] != null)
            {
                lblName.Text =(Session["email1"].ToString());
                  btnLogin.Visible = false;
                Buttoncikis.Visible = true;
            }
            else
            {
                btnLogin.Visible = true;
                lblName.Visible = false;
                Buttoncikis.Visible = false;
            }
            //kullanici.Text = ("Hoşgeldiniz " + Session["email1"].ToString());
            //Response.Write("Hoşgeldiniz " + Session["email1"].ToString());


            //   kullanici.Text = ("Hoşgeldiniz " + Session["email1"].ToString());
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
           
                Response.Redirect("giriskayit.aspx");
            btnLogin.Visible = false;
                lblName.Visible = false;

            


            //Response.Redirect("giriskayit.aspx");
            //btnLogin.Visible = false;

        }

        protected void Buttoncikis_Click(object sender, EventArgs e)
        {
            Session["email1"] = null;
            Buttoncikis.Visible = false ;
             btnLogin.Visible = true;
            lblName.Visible = false;



        }
    }
}