﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;

namespace yazilimproje
{
    public partial class YENİ : System.Web.UI.Page
    {
        SqlConnection baglan = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {



            SqlCommand komut = new SqlCommand();

            SqlDataAdapter da = new SqlDataAdapter(komut);

            DataSet ds = new DataSet();



            komut.CommandText =  "Select * from tartisma1";

 

        komut.Connection = baglan;

        baglan.Open();

 

        komut.ExecuteNonQuery();

 

        da.Fill(ds);

 

        baglan.Close();

 

        GridView1.DataSource = ds;

 

        GridView1.DataBind();

 


        }


    protected void lnkdelete_Click(object sender, EventArgs e)
        {

            
          
        }
        protected void Button2_Click(object sender, EventArgs e)
        {




        }
        protected void Gridview1_SelectedIndexChanged(object sender, EventArgs e)

        {

            //gridview secili satirdaki degerleri textbox aktariyoruz.

            TextBox4.Text = GridView1.SelectedRow.Cells[1].Text;

            TextBox3.Text = GridView1.SelectedRow.Cells[2].Text;

          

            //secili satir rengini degistiriyoruz.

            foreach (GridViewRow row in GridView1.Rows)

            {

                if (row.RowIndex == GridView1.SelectedIndex)

                {

                    row.BackColor = ColorTranslator.FromHtml("Red");



                }

                else

                {

                    row.BackColor = ColorTranslator.FromHtml("White");



                }

            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");

            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
            SqlCommand sqlCmd = new SqlCommand("tartismaBirYorum", sqlCon);
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.AddWithValue("@kullaniciadi", txtEmail.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@yorum", txtYorum.Text.Trim());
            sqlCmd.ExecuteNonQuery();
            sqlCon.Close();

            lblSuccessMessage.Text = "Saved succesfully";



        }
    
        protected void sil_Click(object sender, EventArgs e)
        {

            string numarasi = TextBox3.Text;
            SqlConnection baglanti = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=NotrSpor;Integrated Security=True");

          //  SqlConnection baglanti = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["baglantiCumlemiz"].ConnectionString);
            SqlCommand silKomutu = new SqlCommand("DELETE FROM tartisma1 WHERE yorum=@yorum", baglanti);
            silKomutu.Parameters.AddWithValue("@yorum", numarasi);
            baglanti.Open();
            silKomutu.ExecuteNonQuery();
            baglanti.Close();
            Page.Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);

        }
    }
}